// Simple in-memory storage for demo (in production, use Vercel KV or a database)
// For persistent storage on Vercel, you would need to set up Vercel KV or use a database

let dataStore = {
  watchlist: [],
  watching: [],
  watched: []
};

module.exports = async (req, res) => {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  // GET request - retrieve data
  if (req.method === 'GET') {
    return res.status(200).json(dataStore);
  }

  // POST request - save data
  if (req.method === 'POST') {
    const { watchlist, watching, watched } = req.body;
    
    if (watchlist !== undefined) {
      dataStore.watchlist = watchlist;
    }
    if (watching !== undefined) {
      dataStore.watching = watching;
    }
    if (watched !== undefined) {
      dataStore.watched = watched;
    }

    return res.status(200).json({ success: true, data: dataStore });
  }

  return res.status(405).json({ error: 'Method not allowed' });
};
