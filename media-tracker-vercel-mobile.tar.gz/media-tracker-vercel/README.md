# Media Tracker App - Deployment Guide

## Features
✅ Login authentication (Username: Yonik, Password: nikyo@2121)
✅ Discover movies, TV shows, and anime from all regions
✅ Pagination with 20 items per page
✅ Sort by A-Z, Z-A, and rating
✅ Four tabs: Discover, Watchlist, Watching, Watched
✅ Persistent storage
✅ Dynamic search with live suggestions

## Quick Deploy to Vercel

### Option 1: Using Vercel CLI (Recommended for persistence)

1. **Install Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Navigate to project directory**
   ```bash
   cd media-tracker-vercel
   ```

3. **Install dependencies**
   ```bash
   npm install
   ```

4. **Deploy to Vercel**
   ```bash
   vercel
   ```
   
   Follow the prompts:
   - Link to existing project? No
   - Project name: media-tracker (or your choice)
   - Directory: ./ 
   - Override settings? No

5. **Your app will be live!**
   Vercel will provide you with a URL like: `https://media-tracker-xyz.vercel.app`

### Option 2: Using Vercel Dashboard

1. **Push code to GitHub**
   - Create a new repository on GitHub
   - Push the `media-tracker-vercel` folder to GitHub

2. **Import to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import your GitHub repository
   - Click "Deploy"

3. **Done!**
   Your app will be live at the provided URL

## Important Notes About Data Persistence

⚠️ **Current Setup**: The current API uses in-memory storage, which means data will reset when the serverless function restarts.

### For True Persistence (Production Use):

You have two options:

#### Option A: Use Vercel KV (Recommended - Easiest)

1. Go to your Vercel dashboard
2. Navigate to Storage → Create Database → KV
3. Connect it to your project
4. Update `api/data.js` to use Vercel KV:

```javascript
import { kv } from '@vercel/kv';

module.exports = async (req, res) => {
  // ... CORS headers ...

  if (req.method === 'GET') {
    const watchlist = await kv.get('watchlist') || [];
    const watching = await kv.get('watching') || [];
    const watched = await kv.get('watched') || [];
    return res.status(200).json({ watchlist, watching, watched });
  }

  if (req.method === 'POST') {
    const { watchlist, watching, watched } = req.body;
    if (watchlist) await kv.set('watchlist', watchlist);
    if (watching) await kv.set('watching', watching);
    if (watched) await kv.set('watched', watched);
    return res.status(200).json({ success: true });
  }
};
```

#### Option B: Use a Database (MongoDB, PostgreSQL, etc.)

Connect to any database service and update the API accordingly.

## Current Storage Behavior

- ✅ Data persists in your browser's localStorage
- ⚠️ Server-side storage resets on function cold starts
- 💡 For single-user use, localStorage works perfectly fine
- 🔒 Login credentials protect your data from other users

## Login Credentials

- **Username**: Yonik
- **Password**: nikyo@2121

## API Endpoints

- `GET /api/data` - Retrieve all data
- `POST /api/data` - Save data

## Testing Locally

```bash
npm install
vercel dev
```

Then open http://localhost:3000

## Environment Variables

No environment variables needed for basic deployment. The TMDB API key is already included in the frontend code.

## Support

If you need help with:
- Setting up Vercel KV for persistence
- Connecting to a database
- Custom domain setup

Let me know!
